import { useState } from "react";

const Card = ({ children, className = "" }) => (
  <div className={`rounded-xl border shadow-sm ${className}`}>{children}</div>
);

const CardContent = ({ children, className = "" }) => (
  <div className={`p-4 ${className}`}>{children}</div>
);

const Button = ({ children, className = "", ...props }) => (
  <button
    className={`px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 ${className}`}
    {...props}
  >
    {children}
  </button>
);

// System fonts: Georgia for headers, Arial for body
const headerFont = { fontFamily: "Georgia, serif" };
const bodyFont = { fontFamily: "Arial, Helvetica, sans-serif" };

// Each question block (10 sets)
const questions = [
  [
    { word: "Enthusiastic", type: "I" },
    { word: "Bold", type: "D" },
    { word: "Conscientious", type: "C" },
    { word: "Friendly", type: "S" },
  ],
  [
    { word: "Logical", type: "C" },
    { word: "Attractive", type: "I" },
    { word: "Good-natured", type: "S" },
    { word: "Outspoken", type: "D" },
  ],
  [
    { word: "Agreeable", type: "S" },
    { word: "Outgoing", type: "I" },
    { word: "Daring", type: "D" },
    { word: "Careful", type: "C" },
  ],
  [
    { word: "Strong-willed", type: "D" },
    { word: "Tactful", type: "C" },
    { word: "Sympathetic", type: "S" },
    { word: "Charming", type: "I" },
  ],
  [
    { word: "Gentle", type: "S" },
    { word: "Well-disciplined", type: "C" },
    { word: "Talkative", type: "I" },
    { word: "Charming", type: "D" },
  ],
  [
    { word: "Competitive", type: "D" },
    { word: "Even-tempered", type: "S" },
    { word: "Good Mixer", type: "I" },
    { word: "Thorough", type: "C" },
  ],
  [
    { word: "Sociable", type: "I" },
    { word: "Dominant", type: "D" },
    { word: "Controlled", type: "C" },
    { word: "Easygoing", type: "S" },
  ],
  [
    { word: "Reserved", type: "C" },
    { word: "Appealing", type: "I" },
    { word: "Kind", type: "S" },
    { word: "Direct", type: "D" },
  ],
  [
    { word: "High-spirited", type: "I" },
    { word: "Amiable", type: "S" },
    { word: "Vigorous", type: "D" },
    { word: "Accurate", type: "C" },
  ],
  [
    { word: "Restless", type: "D" },
    { word: "Expressive", type: "I" },
    { word: "Diplomatic", type: "C" },
    { word: "Considerate", type: "S" },
  ],
];

const styleDescriptions = {
  D: "Dominance: Results-oriented, direct, and competitive. They thrive on challenges and value efficiency.",
  I: "Influence: Enthusiastic, persuasive, and sociable. They excel at motivating others and building connections.",
  S: "Steadiness: Patient, supportive, and dependable. They value harmony, cooperation, and consistency.",
  C: "Conscientiousness: Detail-oriented, analytical, and precise. They value accuracy, quality, and structure.",
};

export default function App() {
  const [responses, setResponses] = useState({});
  const [showResult, setShowResult] = useState(false);

  const handleSelect = (qIndex, word, type, value) => {
    const current = responses[qIndex] || {};
    const updated = Object.fromEntries(
      Object.entries(current).filter(([k, v]) => v.value !== value)
    );
    updated[word] = { type, value };
    setResponses({ ...responses, [qIndex]: updated });
  };

  const calculateResults = () => {
    let scores = { D: 0, I: 0, S: 0, C: 0 };
    Object.values(responses).forEach((group) => {
      Object.values(group).forEach(({ type, value }) => {
        scores[type] += value;
      });
    });
    return scores;
  };

  const allAnswered = questions.every((_, qIndex) => {
    const group = responses[qIndex];
    if (!group) return false;
    const values = Object.values(group).map((g) => g.value);
    return [1, 2, 3, 4].every((num) => values.includes(num));
  });

  const results = calculateResults();
  const highest = Object.keys(results).reduce((a, b) =>
    results[a] > results[b] ? a : b
  );

  const NumberButton = ({ label, disabled, selected, onClick }) => (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-pressed={selected}
      className={`px-3 py-2 rounded-lg border text-sm md:text-base focus:outline-none focus:ring-2 focus:ring-offset-1 w-full ${
        selected ? "ring-2 ring-offset-1" : ""
      } ${disabled ? "opacity-50 cursor-not-allowed" : "active:scale-[.98]"}`}
    >
      {label}
    </button>
  );

  return (
    <div style={bodyFont} className="p-4 max-w-2xl mx-auto">
      {!showResult ? (
        <>
          <h1 className="text-2xl font-bold mb-4 text-center" style={headerFont}>
            DiSC Assessment
          </h1>

          <Card className="mb-4">
            <CardContent className="text-sm md:text-base p-4">
              <p className="font-semibold mb-2" style={headerFont}>
                How to rank each set
              </p>
              <ul className="list-disc pl-5 space-y-1">
                <li>
                  Choose each number <span className="font-semibold">once per row</span>:
                  <span className="ml-2 inline-block">4 = Most Like Me</span>,
                  <span className="ml-2 inline-block">3 = Somewhat Like Me</span>,
                  <span className="ml-2 inline-block">2 = Less Like Me</span>,
                  <span className="ml-2 inline-block">1 = Least Like Me</span>.
                </li>
                <li>
                  Tap a number to assign it. Used numbers are disabled for the
                  other words in the set.
                </li>
              </ul>
            </CardContent>
          </Card>

          {questions.map((group, qIndex) => (
            <Card key={qIndex} className="mb-4">
              <CardContent className="space-y-3 p-4">
                <p className="font-semibold" style={headerFont}>
                  Question {qIndex + 1}
                </p>
                {group.map((item, i) => {
                  const selectedVal = responses[qIndex]?.[item.word]?.value;
                  return (
                    <div key={i} className="flex items-center gap-3">
                      <span className="min-w-[8rem] flex-1">{item.word}</span>
                      <div className="grid grid-cols-4 gap-2 w-56">
                        {[4, 3, 2, 1].map((num) => {
                          const usedByOther = Object.entries(responses[qIndex] || {}).some(
                            ([w, v]) => v.value === num && w !== item.word
                          );
                          return (
                            <NumberButton
                              key={num}
                              label={`${num}`}
                              disabled={usedByOther}
                              selected={selectedVal === num}
                              onClick={() => handleSelect(qIndex, item.word, item.type, num)}
                            />
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          ))}

          <Button
            onClick={() => setShowResult(true)}
            className="w-full mt-4 bg-blue-600 text-white hover:bg-blue-700"
            disabled={!allAnswered}
          >
            Submit
          </Button>
          {!allAnswered && (
            <p className="text-red-600 text-sm mt-2">
              Please complete all rankings before submitting.
            </p>
          )}
        </>
      ) : (
        <Card>
          <CardContent className="p-4 space-y-2">
            <h2 className="text-xl font-bold" style={headerFont}>
              Your Results
            </h2>
            <ul className="space-y-1">
              {Object.entries(results).map(([key, value]) => (
                <li key={key}>
                  {key}: {value} – {styleDescriptions[key]}
                </li>
              ))}
            </ul>
            <p className="mt-4 font-semibold" style={headerFont}>
              Your Primary Style: <span className="text-blue-600">{highest}</span>
            </p>
            <p className="mt-2 text-gray-700">{styleDescriptions[highest]}</p>
            <Button
              onClick={() => setShowResult(false)}
              className="mt-4 bg-blue-600 text-white hover:bg-blue-700"
            >
              Retake
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
